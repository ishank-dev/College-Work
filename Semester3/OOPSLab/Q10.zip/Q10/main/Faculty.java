package main;

public class Faculty {
    public String name, designation, joiningDate, subjectsHandled;
    public int age, yearsOfExperience;
}